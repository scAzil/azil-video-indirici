@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
if not exist ".venv\Scripts\python.exe" (
  echo Ilk acilista Python ortami hazirlaniyor...
  %PY% -m venv .venv
  if errorlevel 1 (echo Python 3.10 veya uzeri yukleyin. & pause & exit /b 1)
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (echo Internet veya bagimlilik hatasi. & pause & exit /b 1)
)
".venv\Scripts\python.exe" app.py
if errorlevel 1 pause
