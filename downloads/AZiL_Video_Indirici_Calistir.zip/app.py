"""AZiL Video Indirici — hafif Windows arayuzu, yt-dlp tabanli.

Yalnizca indirmeye hakkiniz olan medyalari kullanin.
"""
import queue
import re
import subprocess
import sys
import threading
from pathlib import Path
from urllib.parse import urlsplit
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP_NAME = "AZiL Video İndirici"
DEFAULT_DIR = Path.home() / "Downloads" / "AZiL"


def valid_url(value):
    try:
        parsed = urlsplit(value.strip())
        return parsed.scheme in ("http", "https") and bool(parsed.netloc) and not parsed.username and not parsed.password
    except ValueError:
        return False


def command(url, directory, mode, quality, ffmpeg_path=None):
    args = [sys.executable, "-m", "yt_dlp", "--newline", "--no-playlist", "--ignore-config", "--no-overwrites",
            "-P", str(directory), "-o", "%(title).180B [%(id)s].%(ext)s"]
    if ffmpeg_path:
        args += ["--ffmpeg-location", str(ffmpeg_path)]
    if mode == "MP3":
        args += ["-x", "--audio-format", "mp3", "--audio-quality", "0"]
    elif quality == "720p":
        args += ["-f", "bv*[height<=720]+ba/b[height<=720]/b"]
    elif quality == "480p":
        args += ["-f", "bv*[height<=480]+ba/b[height<=480]/b"]
    else:
        args += ["-f", "bv*+ba/b"]
    return args + ["--", url]


def ffmpeg_binary():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME + " — 0.2")
        self.minsize(680, 550)
        self.geometry("770x620")
        self.configure(bg="#111216")
        self.url = tk.StringVar()
        self.folder = tk.StringVar(value=str(DEFAULT_DIR))
        self.mode = tk.StringVar(value="Video")
        self.quality = tk.StringVar(value="En yüksek")
        self.message = tk.StringVar(value="Hazır. URL ekleyerek kuyruğu oluşturun.")
        self.events = queue.Queue()
        self.items = []
        self.process = None
        self.cancel_requested = False
        self.worker = None
        self._layout()
        self.after(100, self._poll)
        self.protocol("WM_DELETE_WINDOW", self._close)

    def _layout(self):
        dark, panel, ink, lime = "#111216", "#1b1e24", "#f4f4ef", "#d5f778"
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Az.TFrame", background=dark)
        style.configure("Az.TLabel", background=dark, foreground=ink, font=("Segoe UI", 10))
        style.configure("Az.TButton", background=panel, foreground=ink, padding=8)
        style.map("Az.TButton", background=[("active", "#343941")])
        style.configure("Az.TCombobox", fieldbackground=panel, background=panel, foreground="#111216")
        body = ttk.Frame(self, padding=22, style="Az.TFrame")
        body.pack(fill="both", expand=True)
        tk.Label(body, text="AZiL / MASAÜSTÜ", bg=dark, fg=lime, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(body, text="Video İndirici", bg=dark, fg=ink, font=("Segoe UI", 25, "bold")).pack(anchor="w", pady=(2, 18))
        ttk.Label(body, text="İndirilecek medya bağlantısı", style="Az.TLabel").pack(anchor="w")
        row = ttk.Frame(body, style="Az.TFrame")
        row.pack(fill="x", pady=(5, 13))
        ttk.Entry(row, textvariable=self.url).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Kuyruğa ekle", command=self._add).pack(side="left", padx=(8, 0))
        ttk.Label(body, text="Kaydetme klasörü", style="Az.TLabel").pack(anchor="w")
        frow = ttk.Frame(body, style="Az.TFrame")
        frow.pack(fill="x", pady=(5, 13))
        ttk.Entry(frow, textvariable=self.folder).pack(side="left", fill="x", expand=True)
        ttk.Button(frow, text="Seç", command=self._choose).pack(side="left", padx=(8, 0))
        opts = ttk.Frame(body, style="Az.TFrame")
        opts.pack(fill="x", pady=(0, 12))
        ttk.Label(opts, text="Tür:", style="Az.TLabel").pack(side="left")
        ttk.Combobox(opts, values=("Video", "MP3"), textvariable=self.mode, state="readonly", width=11).pack(side="left", padx=(6, 26))
        ttk.Label(opts, text="Kalite:", style="Az.TLabel").pack(side="left")
        ttk.Combobox(opts, values=("En yüksek", "720p", "480p"), textvariable=self.quality, state="readonly", width=15).pack(side="left", padx=6)
        ttk.Label(body, text="İndirme kuyruğu", style="Az.TLabel").pack(anchor="w")
        self.listbox = tk.Listbox(body, height=7, bg=panel, fg=ink, selectbackground="#365054", relief="flat", highlightthickness=1, highlightbackground="#353941", font=("Segoe UI", 10))
        self.listbox.pack(fill="both", expand=True, pady=(5, 10))
        buttons = ttk.Frame(body, style="Az.TFrame")
        buttons.pack(fill="x")
        ttk.Button(buttons, text="İndirmeyi başlat", command=self._start).pack(side="left")
        ttk.Button(buttons, text="Durdur", command=self._stop).pack(side="left", padx=8)
        ttk.Button(buttons, text="Kuyruğu temizle", command=self._clear).pack(side="right")
        ttk.Label(body, textvariable=self.message, style="Az.TLabel", wraplength=700).pack(anchor="w", pady=(16, 7))
        self.log = tk.Text(body, height=5, bg=panel, fg="#c5cfda", insertbackground=ink, relief="flat", state="disabled", font=("Consolas", 9))
        self.log.pack(fill="x")
        tk.Label(body, text="Yalnızca indirme izniniz bulunan içerikleri kullanın. DRM koruması aşılmaz.", bg=dark, fg="#b9bec8", font=("Segoe UI", 9)).pack(anchor="w", pady=(12, 0))

    def _add(self):
        value = self.url.get().strip()
        if not valid_url(value):
            messagebox.showerror("Geçersiz bağlantı", "http:// veya https:// ile başlayan geçerli bağlantı girin.")
            return
        self.items.append((value, self.mode.get(), self.quality.get()))
        self.listbox.insert("end", f"{self.mode.get()} | {value}")
        self.url.set("")
        self.message.set(f"Kuyrukta {len(self.items)} bağlantı bulunuyor.")

    def _choose(self):
        path = filedialog.askdirectory(initialdir=str(Path.home()))
        if path:
            self.folder.set(path)

    def _clear(self):
        if self.worker and self.worker.is_alive():
            return
        self.items.clear()
        self.listbox.delete(0, "end")
        self.message.set("Kuyruk temizlendi.")

    def _start(self):
        if self.worker and self.worker.is_alive():
            self.message.set("İndirme zaten devam ediyor.")
            return
        if not self.items:
            self.message.set("Önce bağlantı ekleyin.")
            return
        path = Path(self.folder.get()).expanduser()
        try:
            path.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            messagebox.showerror("Klasör oluşturulamadı", str(e))
            return
        try:
            import yt_dlp  # noqa: F401
        except ImportError:
            messagebox.showerror("Eksik bileşen", "Önce BASLAT.bat çalıştırarak gereksinimleri yükleyin.")
            return
        self.cancel_requested = False
        self.worker = threading.Thread(target=self._download, args=(list(self.items), path), daemon=True)
        self.worker.start()

    def _download(self, items, path):
        ffmpeg = ffmpeg_binary()
        for i, (url, mode, quality) in enumerate(items, start=1):
            if self.cancel_requested:
                break
            self.events.put(("status", f"{i}/{len(items)} indiriliyor: {url}"))
            try:
                cmd = command(url, path, mode, quality, ffmpeg)
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                self.process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                                text=True, encoding="utf-8", errors="replace", creationflags=flags)
                for line in self.process.stdout:
                    if self.cancel_requested:
                        self.process.terminate()
                        break
                    line = line.strip()
                    if line:
                        self.events.put(("log", line))
                        if "[download]" in line:
                            self.events.put(("status", f"{i}/{len(items)} — {line[-95:]}"))
                code = self.process.wait()
                if code != 0 and not self.cancel_requested:
                    self.events.put(("log", f"Hata: indirme kodu {code}. Format/bağlantı desteklenmeyebilir."))
            except Exception as e:
                self.events.put(("log", f"Hata: {e}"))
            finally:
                self.process = None
        self.events.put(("done", "İndirme durduruldu." if self.cancel_requested else "Kuyruk tamamlandı. Sonuçlar için günlük alanını kontrol edin."))

    def _stop(self):
        self.cancel_requested = True
        if self.process and self.process.poll() is None:
            try:
                self.process.terminate()
            except OSError:
                pass
        self.message.set("Durdurma istendi...")

    def _poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind in ("status", "done"):
                    self.message.set(value)
                if kind == "log":
                    self.log.configure(state="normal")
                    self.log.insert("end", value + "\n")
                    self.log.see("end")
                    self.log.configure(state="disabled")
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _close(self):
        self._stop()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
