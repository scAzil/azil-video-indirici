# AZiL Video İndirici — hafif başlangıç paketi (0.2)

**Bu, geçmişteki `AZiL_Video_Indirici_v1.zip` dosyasının birebir kopyası değildir.** Önceki arşive erişilemediği için kaynak kodu yeniden hazırlanmış, Windows indirme testi yapılmamıştır.

Windows'ta **Python 3.10+** gerekir. `BASLAT.bat` açıldığında proje klasöründe `.venv` oluşturulur, ilk çalıştırmada internet üzerinden yt-dlp ve ffmpeg bileşenleri kurulur. Ardından Türkçe masaüstü arayüzü açılır. URL ekle, kalite (en yüksek/720p/480p) ve Video/MP3 seç, indirmeyi başlat. Tek URL başına işlem, kuyruk, ilerleme günlüğü ve durdurma bulunur. Koruma/DRM aşma amacı taşımaz. Kullanım platforma ve içeriğin izinlerine tabidir.

## ZIP ve EXE farkı

- `AZiL_Video_Indirici_Calistir.zip`: Python bulunan Windows'ta `BASLAT.bat` ile açılan hafif **kaynak/çalıştırma paketi**. Bağımsız bir EXE değildir.
- `AZiL_Video_Indirici_Hazirlama.zip`: Aynı kaynakla beraber `EXE_OLUSTUR.bat`; PyInstaller'ı kullanarak **Windows üzerinde** EXE üretmek içindir.
- PyInstaller sonucu `dist/AZiL_Video_Indirici.exe` olur. İlk aşamada üçüncü taraf bileşenler (`yt-dlp`, `imageio-ffmpeg`) ve gerekirse ağ gerekir.

### Güvenlik ve sınırlamalar

Kaynak kod, Windows/indirilecek sitelerle canlı indirme açısından doğrulanmış bir sürüm değildir. Yayımlamadan önce gerçek Windows 10/11'de test edilmeli. `yt-dlp` ve `imageio-ffmpeg` açık kaynaklı üçüncü taraf bileşenlerdir ve ilgili lisans/koşullara tabidir. Kullanıcı yalnızca indirme izni bulunan içerikleri indirmelidir. Geçersiz URL'ler engellenir; sitedeki yükleme ve DRM kurallarını atlatmaya yönelik özellik yoktur.
