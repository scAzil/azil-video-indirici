@echo off
setlocal
cd /d "%~dp0"
if not exist app.py (
  echo HATA: Bu hazirlama paketini AZiL_Video_Indirici_Calistir.zip ile ayni klasore acin.
  pause
  exit /b 1
)
python -m pip install --upgrade pyinstaller yt-dlp
if errorlevel 1 exit /b 1
python -m PyInstaller --noconfirm --clean --onefile --windowed --name AZiL_Video_Indirici app.py
if errorlevel 1 exit /b 1
echo Olusan dosya: dist\AZiL_Video_Indirici.exe
pause
