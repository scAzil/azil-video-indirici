AZiL Video Indirici - EXE Hazirlama

1. AZiL_Video_Indirici_Calistir.zip dosyasini ayri bir klasore cikarin.
2. Bu ZIP icindeki EXE_OLUSTUR.bat dosyasini ayni klasore cikarin.
3. Windows uzerinde Python 3.10+ kuruluysa EXE_OLUSTUR.bat dosyasini calistirin.
4. PyInstaller bagimliligi internetten yuklenir. EXE dist klasorunde olusur.
5. EXE icinde ffmpeg ve yt-dlp medya altyapisi gomulu degildir; yt-dlp Python paketi olarak kurulur.

Not: Windows uzerinde derleme ve medya indirme testi henuz gerceklestirilmedi. Yalnizca izinli icerikleri indirin.
